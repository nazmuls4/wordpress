<?php
/*
Plugin Name: Cristina toolkit
Plugin URI: https://static.webmakerbd.net/Cristina/
Description: This is official plugin for Cristina Webmkerbd
Version:     1.0
Author:      Syed Nazmul Hasan
Author URI:  http://webmakerbd.net
License:     GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

*/



//Exit if accessed directly

if(!defined('ABSPATH')){
    exit;
}
//Define
define('CRISTINA_ACC_URL', WP_PLUGIN_URL . '/' .plugin_basename(dirname(__FILE__)) .'/');
define('CRISTINA_ACC_PATH', plugin_dir_path(__FILE__));



/// Post list show

function cristina_toolkit_get_page_list(){
    
    $args = wp_parse_args( array(
        'post_type' => 'page',
        'numberposts'  =>  -1,
    )
        
    );
    $posts = get_posts( $args );
    
    $post_options = array(esc_html('-- select page list --', 'cristina-toolkit')=>'');
    
    if($posts){
        foreach( $posts as $post ){
            $post_options[ $post->post_title] = $post->ID;}
    }
    
    return $post_options;
    
}


// project custom post


add_action( 'init', 'cristina_project_custom_post' );
function cristina_project_custom_post() {
    register_post_type( 'project',
        array(
            'labels' => array(
                'name' => __( 'Project' ),
                'singular_name' => __( 'project' )
            ),
            'supports' => array('title', 'editor', 'thumbnail', 'page-attributes'),
            'public' => true
        )
    );
}


// custom taxonamy

function cristina_project_custom_taxonamy() {
    register_taxonomy(
        'project_category',  
        'project',                  
        array(
            'hierarchical'          => true,
            'label'                 => 'Project Category',  
            'query_var'             => true,
            'show_admin_column'     => true,
            'rewrite'               => array(
                'slug'              => 'project-category', 
                'with_front'    => true 
                )
            )
    );
}
add_action( 'init', 'cristina_project_custom_taxonamy');






//Print shortcodes in widget
add_filter('widget_text', 'do_shortcode');

// cs framework load
require_once(CRISTINA_ACC_PATH . 'inc/cs/cs-framework.php');
require_once(CRISTINA_ACC_PATH . 'inc/cs/metabox-theme-options.php');

//Loading VC addons
require_once(CRISTINA_ACC_PATH . 'vc-addon/vc-blocks-load.php');


//Theme shortcode

require_once(CRISTINA_ACC_PATH .'theme-shortcode/hero-area-shotcode.php');
require_once(CRISTINA_ACC_PATH .'theme-shortcode/common-title-shortcode.php');
require_once(CRISTINA_ACC_PATH .'theme-shortcode/common-btn-shortcode.php');
require_once(CRISTINA_ACC_PATH .'theme-shortcode/skilled-shortcode.php');
require_once(CRISTINA_ACC_PATH .'theme-shortcode/experience-shortcode.php');
require_once(CRISTINA_ACC_PATH .'theme-shortcode/education-shortcode.php');
require_once(CRISTINA_ACC_PATH .'theme-shortcode/contact-info-shortcode.php');
require_once(CRISTINA_ACC_PATH .'theme-shortcode/project-shortcode.php');


//Shortcodes depended on visual composer
include_once(ABSPATH . 'wp-admin/includes/plugin.php');

function Cristina_toolkit_file(){
        
    wp_enqueue_style('Cristina-style', plugin_dir_url(__FILE__) . 'asset/css/toolkit-style.css', array(), '1.0');
     wp_enqueue_script('isotope.pkgd', plugin_dir_url(__FILE__) . 'asset/js/isotope.pkgd.min.js' , array('jquery'), '2.3.0' , true);  
     wp_enqueue_script('Cristina-active', plugin_dir_url(__FILE__) . 'asset/js/active-plugin.js' , array('jquery'), '1.0' , true);  
    
   
}
add_action('wp_enqueue_scripts','Cristina_toolkit_file');





