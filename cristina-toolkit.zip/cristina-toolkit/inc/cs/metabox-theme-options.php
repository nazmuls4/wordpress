<?php
if (!defined('ABSPATH')) {
    die;
}


// framework options filter example

function cristina_custom_metabox_options($options)
{
    
    $options = array();
    
    // -----------------------------------------
    // Page Metabox Options                    -
    // -----------------------------------------
    $options[] = array(
        'id' => 'cristina_custom_page_option',
        'title' => 'Custom Page Options',
        'post_type' => 'page',
        'context' => 'normal',
        'priority' => 'default',
        
        'sections' => array(
            
            array(
                'name' => 'cristina_custom_page_content',
                
                
                'fields' => array(
                    
                    array(
                        'id' => 'enable_title',
                        'type' => 'switcher',
                        'title' => 'Enable Title?',
                        'default' => false,
                        'desc' => esc_html__('Enable Custom Title, Turn on switch', 'cristina-webmakerbd')
                        
                    ),
                    
                    array(
                        'id' => 'custom_page_title',
                        'type' => 'text',
                        'title' => 'Type Your Custom Title',
                        'desc' => esc_html__('Type your Custom Title : Exam: Service Content', 'cristina-webmakerbd'),
                        'dependency' => array(
                            'enable_title',
                            '==',
                            'true'
                        )
                    ),
                    
                    array(
                        'id' => 'overlay_perchanetage',
                        'type' => 'text',
                        'title' => 'Overlay perchantage',
                        'default' => '.6',
                        'desc' => esc_html__('Type overlay perchantage, In floating Number like: 03, 04, 05, 06  , Maximum is 1, ', 'cristina-webmakerbd'),
                        'dependency' => array(
                            'enable_title',
                            '==',
                            'true'
                        )
                    ),
                    array(
                        'id' => 'page_bradcum_overlay_color',
                        'type' => 'color_picker',
                        'title' => 'Select color',
                        'default' => '#1abc9c',
                        'desc' => esc_html__('Select Overlay color', 'cristina-webmakerbd'),
                        'dependency' => array(
                            'enable_title',
                            '==',
                            'true'
                        )
                    )
                    
                    
                    
                    
                )
            )
        )
        
    );
    
    
    // -----------------------------------------
    // Page Metabox Options                    -
    // -----------------------------------------
    $options[] = array(
        'id' => 'cristina_project_option',
        'title' => 'Custom Project Options',
        'post_type' => 'project',
        'context' => 'normal',
        'priority' => 'default',
        
        'sections' => array(
            
            array(
                'name' => 'cristina_custom_page_content',
                
                
                'fields' => array(
                    
                    array(
                        'id' => 'enable_information',
                        'type' => 'switcher',
                        'title' => 'Ebable Project Information',
                        'default' => false,
                        'desc' => esc_html__('Do you want to Ebable Project Information, Turn on switch', 'cristina-webmakerbd')
                        
                    ),
                    
                    array(
                        'id' => 'client_name',
                        'type' => 'text',
                        'title' => 'Client Name',
                        'default' => 'Client Name',
                        'desc' => esc_html__('Type Client Name', 'cristina-webmakerbd'),
                        'dependency' => array(
                            'enable_information',
                            '==',
                            'true'
                        )
                    ),
                    
                    array(
                        'id' => 'Date',
                        'type' => 'text',
                        'title' => 'Complete Date',
                        'default' => 'May 14, 2018',
                        'desc' => esc_html__('Select Complete Date', 'cristina-webmakerbd'),
                        'dependency' => array(
                            'enable_information',
                            '==',
                            'true'
                        )
                    ),
                    
                    array(
                        'id' => 'project_type',
                        'type' => 'text',
                        'title' => 'Project Type',
                        'default' => 'Multipurpose Template',
                        'desc' => esc_html__('Type Project Type: Examplet Multipurpose Website Template', 'cristina-webmakerbd'),
                        'dependency' => array(
                            'enable_information',
                            '==',
                            'true'
                        )
                    ),
                    array(
                        'id' => 'live_project',
                        'type' => 'text',
                        'title' => 'Live Project Link',
                        'default' => 'http://webmakerbd.net',
                        'desc' => esc_html__('Type Live Project Link', 'cristina-webmakerbd'),
                        'dependency' => array(
                            'enable_information',
                            '==',
                            'true'
                        )
                    )
                    
                )
            )
        )
        
    );
    
    
    return $options;
    
}
add_filter('cs_metabox_options', 'cristina_custom_metabox_options');






function cristina_framework_metabox_options($options)
{
    
    $options = array(); // exixtance options remove
    
    // ----------------------------------------
    // Header Theme Options
    // ----------------------------------------
    $options[] = array(
        'name' => 'crostina_header_framework_Options',
        'title' => esc_html__('Header Option', 'cristina-webmakerbd'),
        'icon' => 'fa fa-inbox',
        
        // begin: fields
        'fields' => array(
            
            array(
                'id' => 'text_logo',
                'type' => 'text',
                'title' => esc_html__('Text Logo', 'cristina-webmakerbd'),
                'desc' => esc_html__('Type Text Logo', 'cristina-webmakerbd'),
                'default' => 'Cristina',
                'dependency' => array(
                    'logo_upload',
                    '==',
                    'false'
                )
                
            ),
            
            array(
                'id' => 'logo_upload',
                'type' => 'switcher',
                'default' => 'false',
                'title' => esc_html__('Upload logo', 'cristina-webmakerbd'),
                'desc' => esc_html__('Do you want to Upload logo? Turn On The Switch', 'cristina-webmakerbd')
                
            ),
            array(
                'id' => 'image_logo',
                'type' => 'image',
                'title' => esc_html__('Upload Image Logo', 'cristina-webmakerbd'),
                'desc' => esc_html__('Upload Image Logo', 'cristina-webmakerbd'),
                'dependency' => array(
                    'logo_upload',
                    '==',
                    'true'
                )
                
            ),
            
            array(
                'id' => 'image_logo_size',
                'type' => 'text',
                'title' => esc_html__('Logo Width', 'cristina-webmakerbd'),
                'desc' => esc_html__('Type Logo Width', 'cristina-webmakerbd'),
                'default' => '100',
                'dependency' => array(
                    'logo_upload',
                    '==',
                    'true'
                )
                
            ),
            array(
                'id' => 'image_logo_height',
                'type' => 'text',
                'title' => esc_html__('Logo Height', 'cristina-webmakerbd'),
                'desc' => esc_html__('Type Logo Height', 'cristina-webmakerbd'),
                'default' => '50',
                'dependency' => array(
                    'logo_upload',
                    '==',
                    'true'
                )
                
            ),
            
            array(
                'id' => 'header_social_list',
                'type' => 'group',
                'title' => esc_html__('Header socila list', 'cristina-webmakerbd'),
                'button_title' => 'Add New',
                'accordion_title' => 'Add New Header social List',
                'fields' => array(
                    
                    array(
                        'id' => 'header_social_icon',
                        'type' => 'icon',
                        'title' => esc_html__('Social Icon', 'cristina-webmakerbd'),
                        'desc' => esc_html__('Select Social Icon', 'cristina-webmakerbd'),
                        'default' => 'fa fa-facebook-f'
                        
                    ),
                    array(
                        'id' => 'header_social_link',
                        'type' => 'text',
                        'title' => esc_html__('Social Link', 'cristina-webmakerbd'),
                        'desc' => esc_html__('Type Social Link', 'cristina-webmakerbd'),
                        'default' => 'https://facebook.com'
                        
                    )
                    
                )
            )
            
        ) // end: fields
    );
    
    
    // ----------------------------------------
    // footer Theme Options
    // ----------------------------------------
    $options[] = array(
        'name' => 'crostina_footer_framework_option',
        'title' => esc_html__('Footer Options', 'cristina-webmakerbd'),
        'icon' => 'fa fa-star',
        
        // begin: fields
        'fields' => array(
            
            array(
                'id' => 'copyright_text',
                'type' => 'textarea',
                'title' => esc_html__('Footer Copyright Text', 'cristina-webmakerbd'),
                'desc' => esc_html__('Type Footer Copyright Texto', 'cristina-webmakerbd'),
                'default' => '2019 Cristina. Design by Webmakerbd'
                
            ),
            array(
                'id' => 'footer_top_background',
                'type' => 'color_picker',
                'title' => esc_html__('Footer Top Background', 'cristina-webmakerbd'),
                'desc' => esc_html__('Select Footer Top Background', 'cristina-webmakerbd'),
                'default' => '#f2f2f2'
                
            ),
            
            array(
                'id' => 'footer_social_list',
                'type' => 'group',
                'title' => esc_html__('Footer socila list', 'cristina-webmakerbd'),
                'button_title' => 'Add New',
                'accordion_title' => 'Add New Footer social List',
                'fields' => array(
                    
                    array(
                        'id' => 'footer_social_name',
                        'type' => 'text',
                        'title' => esc_html__('Social Name', 'cristina-webmakerbd'),
                        'desc' => esc_html__('Type Social Name', 'cristina-webmakerbd'),
                        'default' => 'Facebook'
                        
                    ),
                    array(
                        'id' => 'footer_social_icon',
                        'type' => 'icon',
                        'title' => esc_html__('Social Icon', 'cristina-webmakerbd'),
                        'desc' => esc_html__('Select Social Icon', 'cristina-webmakerbd'),
                        'default' => 'fa fa-facebook-f'
                        
                    ),
                    array(
                        'id' => 'footer_social_link',
                        'type' => 'text',
                        'title' => esc_html__('Social Link', 'cristina-webmakerbd'),
                        'desc' => esc_html__('Type Social Link', 'cristina-webmakerbd'),
                        'default' => 'https://facebook.com'
                        
                    )
                    
                )
            )
            
        ) // end: fields
    );
    
    // ----------------------------------------
    // Style Theme Options
    // ----------------------------------------
    $options[] = array(
        'name' => 'crostina_style_framework_option',
        'title' => esc_html__('Style Options', 'cristina-webmakerbd'),
        'icon' => 'fa fa-heart',
        
        // begin: fields
        'fields' => array(
            
            array(
                'id' => 'proloader',
                'type' => 'switcher',
                'default' => true,
                'title' => esc_html__('Preloader Option', 'cristina-webmakerbd'),
                'desc' => esc_html__('Do you Want to Preloader Option? Or No? Just turn On Or Off the Switcher.', 'cristina-webmakerbd')
                
            ),
            array(
                'id' => 'primary_background',
                'type' => 'color_picker',
                'title' => esc_html__('Primary Color', 'cristina-webmakerbd'),
                'desc' => esc_html__('Select Theme Primary Color', 'cristina-webmakerbd'),
                'default' => '#17bc9b'
                
            ),
            array(
                'id' => 'seconday_background',
                'type' => 'color_picker',
                'title' => esc_html__('Secondary Color', 'cristina-webmakerbd'),
                'desc' => esc_html__('Select Theme Secondary Color', 'cristina-webmakerbd'),
                'default' => '#0c0c0c'
                
            ),
            array(
                'id' => 'body_background',
                'type' => 'color_picker',
                'title' => esc_html__('Theme Body Background', 'cristina-webmakerbd'),
                'desc' => esc_html__('Select Theme Body Background Color', 'cristina-webmakerbd'),
                'default' => '#d9dcd7'
                
            ),
            array(
                'id' => 'body_Content_area_background',
                'type' => 'color_picker',
                'title' => esc_html__('Theme Body Content Area Background', 'cristina-webmakerbd'),
                'desc' => esc_html__('Select Theme Body Content Area Background', 'cristina-webmakerbd'),
                'default' => '#fff'
                
            ),
            array(
                'id' => 'primary_font_color',
                'type' => 'color_picker',
                'title' => esc_html__('Primary Font Color', 'cristina-webmakerbd'),
                'desc' => esc_html__('Select Primary Font Color', 'cristina-webmakerbd'),
                'default' => '#fff'
                
            )
            
        ) // end: fields
    );
    
    
    // ----------------------------------------
    // Typography Theme Options
    // ----------------------------------------
    $options[] = array(
        'name' => 'crostina_typography_framework_option',
        'title' => esc_html__('Typography Options', 'cristina-webmakerbd'),
        'icon' => 'fa fa-paragraph',
        
        // begin: fields
        'fields' => array(
            
            array(
                'id' => 'body_font',
                'type' => 'typography',
                'title' => esc_html__('Body Fonts', 'cristina-webmakerbd'),
                'desc' => esc_html__('Select Body Fonts', 'cristina-webmakerbd'),
                'default' => array(
                    'family' => 'Roboto',
                    'font' => 'google', // this is helper for output ( google, websafe, custom )
                    'variant' => 'regular'
                )
            ),
            
            
            array(
                'id' => 'body_font_varient',
                'type' => 'checkbox',
                'title' => esc_html__('Body Font varient', 'cristina-webmakerbd'),
                'desc' => esc_html__('Select Body Font varient', 'cristina-webmakerbd'),
                'options' => array(
                    '100' => '100',
                    '100i' => '100i',
                    '300' => '300',
                    '300i' => '300i',
                    '400' => 'Regular',
                    '400i' => 'Regular Italic',
                    '500' => '500',
                    '500i' => '500i',
                    '600' => '600',
                    '600i' => '600i',
                    '700' => '700',
                    '700i' => '700i',
                    '900' => '900',
                    '900i' => '900i'
                    
                ),
                'default' => array(
                    '300',
                    '400',
                    '700'
                )
            ),
            
            
            array(
                'id' => 'body_font_size',
                'type' => 'text',
                'title' => esc_html__('Body Font Size', 'cristina-webmakerbd'),
                'desc' => esc_html__('Type Body Font Size', 'cristina-webmakerbd'),
                'default' => '15'
                
            ),
            array(
                'id' => 'body_font_line_height',
                'type' => 'text',
                'title' => esc_html__('Body Line Height size', 'cristina-webmakerbd'),
                'desc' => esc_html__('Type Body Line Height size', 'cristina-webmakerbd'),
                'default' => '26'
                
            ),
            
            
            
            array(
                'id' => 'heading_font',
                'type' => 'typography',
                'title' => esc_html__('Heading Fonts', 'cristina-webmakerbd'),
                'desc' => esc_html__('Select Heading Fonts', 'cristina-webmakerbd'),
                'default' => array(
                    'family' => 'Oswald',
                    'font' => 'google', // this is helper for output ( google, websafe, custom )
                    'variant' => '700'
                )
            ),
            
            
            array(
                'id' => 'heading_font_varient',
                'type' => 'checkbox',
                'title' => esc_html__('Heading Font varient', 'cristina-webmakerbd'),
                'desc' => esc_html__('Select Heading Font varient', 'cristina-webmakerbd'),
                'options' => array(
                    '100' => '100',
                    '100i' => '100i',
                    '300' => '300',
                    '300i' => '300i',
                    '400' => 'Regular',
                    '400i' => 'Regular Italic',
                    '500' => '500',
                    '500i' => '500i',
                    '600' => '600',
                    '600i' => '600i',
                    '700' => '700',
                    '700i' => '700i',
                    '900' => '900',
                    '900i' => '900i'
                    
                ),
                'default' => array(
                    '700',
                    '900'
                )
            )
            
            
            
            
        ) // end: fields
    );
    
    
    // ----------------------------------------
    // Blog Theme Options
    // ----------------------------------------
    $options[] = array(
        'name' => 'crostina_blog_framework_option',
        'title' => esc_html__('Blog Options', 'cristina-webmakerbd'),
        'icon' => 'fa fa-paint-brush',
        
        // begin: fields
        'fields' => array(
            
            array(
                'id' => 'display_post_by',
                'type' => 'switcher',
                'default' => true,
                'title' => esc_html__('Display post by ?', 'cristina-webmakerbd'),
                'desc' => esc_html__('Do you want to Show Display post by ? Or Off', 'cristina-webmakerbd')
                
                
            ),
            array(
                'id' => 'display_post_date',
                'type' => 'switcher',
                'default' => true,
                'title' => esc_html__('Display post Date ?', 'cristina-webmakerbd'),
                'desc' => esc_html__('Do you want to Show Display post Date ? Or Off', 'cristina-webmakerbd')
                
                
            ),
            array(
                'id' => 'display_comment_count',
                'type' => 'switcher',
                'default' => true,
                'title' => esc_html__('Display Comment Count?', 'cristina-webmakerbd'),
                'desc' => esc_html__('Do you want to Show Display Comment Count? Or Off', 'cristina-webmakerbd')
                
                
            ),
            array(
                'id' => 'display_categories',
                'type' => 'switcher',
                'default' => true,
                'title' => esc_html__('Display Posted Category?', 'cristina-webmakerbd'),
                'desc' => esc_html__('Do you want to Show Display Posted Category? Or Off', 'cristina-webmakerbd')
                
                
            ),
            array(
                'id' => 'display_post_tag',
                'type' => 'switcher',
                'default' => true,
                'title' => esc_html__('Display Posted Tag?', 'cristina-webmakerbd'),
                'desc' => esc_html__('Do you want to Show Display Posted Tag? Or Off', 'cristina-webmakerbd')
                
                
            ),
            
            array(
                'id' => 'display_single_nav_link',
                'type' => 'switcher',
                'default' => true,
                'title' => esc_html__('Display Single Navigation link?', 'cristina-webmakerbd'),
                'desc' => esc_html__('Do you want to Show Display Single Navigation link? Or Off', 'cristina-webmakerbd')
                
                
            )
            
            
            
            
            
            
        ) // end: fields
    );
    
    
    // ----------------------------------------
    // Script Theme Options
    // ----------------------------------------
    $options[] = array(
        'name' => 'crostina_script_framework_option',
        'title' => esc_html__('Script Options', 'cristina-webmakerbd'),
        'icon' => 'fa fa-print',
        
        // begin: fields
        'fields' => array(
            
            array(
                'id' => 'custom_css_style',
                'type' => 'textarea',
                'default' => '',
                'title' => esc_html__('Custom Css', 'cristina-webmakerbd'),
                'desc' => esc_html__('Style Your Custom Css', 'cristina-webmakerbd'),
                'sanitize' => false
                
            ),
            array(
                'id' => 'head_script',
                'type' => 'textarea',
                'default' => '',
                'title' => esc_html__('Header Script', 'cristina-webmakerbd'),
                'desc' => esc_html__('Do you want to upload Header Script. Note: Ignore include script tag Like < script >< /script >', 'cristina-webmakerbd'),
                'sanitize' => false
                
            ),
            
            array(
                'id' => 'close_body_script',
                'type' => 'textarea',
                'default' => '',
                'title' => esc_html__('Before Body Script', 'cristina-webmakerbd'),
                'desc' => esc_html__('Do you want to upload Before Body Script. It will goes to Before end  < /body > Ignore include script tag Like < script >< /script > ', 'cristina-webmakerbd'),
                'sanitize' => false
                
            )
            
            
        ) // end: fields
    );
    
    
    
    
    
    return $options;
    
}
add_filter('cs_framework_options', 'cristina_framework_metabox_options');


function cristina_freamework_setting($settings)
{
    
    $settings = array();
    $settings = array(
        'menu_title' => 'Theme Options',
        'menu_type' => 'theme', // menu, submenu, options, theme, etc.
        'menu_slug' => 'cristina-framework',
        'ajax_save' => true,
        'show_reset_all' => true,
        'framework_title' => esc_html__('Cristina Theme Options By Webmakerbd', 'cristina-webmakerbd')
    );
    return $settings;
    
}
add_filter('cs_framework_settings', 'cristina_freamework_setting');


function cristina_Customize_options($options)
{
    
    $options = array();
    
}
add_filter('cs_customize_options', 'cristina_Customize_options');

function cristina_shortcode_options($options)
{
    
    $options = array();
    
}
add_filter('cs_shortcode_options', 'cristina_shortcode_options');

