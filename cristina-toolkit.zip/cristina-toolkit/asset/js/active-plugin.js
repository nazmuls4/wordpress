/* ---------------------------------------------
 common scripts
 --------------------------------------------- */
(function($) {
    'use strict'; // use strict to start

    jQuery(document).ready(function($) {
    	
        
	     
		
    });

	

   jQuery(window).load(function(){
	  

        
    });




}(jQuery));