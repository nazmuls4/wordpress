<?php

   vc_map( 
   array(
      "name" => __( "Cistina Skilled", "cistina-toolkit" ),
      "base" => "cristina_skilled",
      "category" => __( "Cistina", "cistina-toolkit"),
      "params" => array(
         
         
         array(
            "type" => "textfield",
            "heading" => esc_html__( "Skilled Tilte", "cistina-toolkit" ),
            "param_name" => "progress_title",
            "std" => 'Photoshop',
            "description" => esc_html__( "Type Skilled Tilte", "cistina-toolkit" )
         ),
         array(
            "type" => "textfield",
            "heading" => esc_html__( "Progress Bar Value", "cistina-toolkit" ),
            "param_name" => "progress_value",
            "std" => '25',
            "description" => esc_html__( "Type Progress Bar Value In Number Only: Like 30", "cistina-toolkit" )
         ),
                
      ) 
   ) );

?>