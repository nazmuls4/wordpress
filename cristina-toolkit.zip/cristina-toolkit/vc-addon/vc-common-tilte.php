<?php

   vc_map( 
   array(
      "name" => __( "Cistina Commont Title", "cistina-toolkit" ),
      "base" => "cristina_common_title",
      "category" => __( "Cistina", "cistina-toolkit"),
      "params" => array(
         
         
         array(
            "type" => "textfield",
            "heading" => esc_html__( "Title Short History", "cistina-toolkit" ),
            "param_name" => "small_heading",
            "std" => 'Who am i ?',
            "description" => esc_html__( "Type Title Short History", "cistina-toolkit" )
         ),
              
         array(
            "type" => "textfield",
            "heading" => esc_html__( "Title Name", "cistina-toolkit" ),
            "param_name" => "big_heading",
            "std" => 'Personal Details',
            "description" => esc_html__( "Type Titlte name", "cistina-toolkit" )
         ),

         
         array(
            "type" => "dropdown",
            "heading" => esc_html__( "Title position", "cistina-toolkit" ),
            "param_name" => "heading_text_position",
            "value" =>array(
              'Text Left' => 'text-left',
              'Text Center' => 'text-center',
              'Text Right' => 'text-right',
              ),
            "std" => "text-left",
            "description" => esc_html__( "Select Title position", "cistina-toolkit" )
         ),    
                
      ) 
   ) );

?>