<?php

   vc_map( 
   array(
      "name" => __( "Cistina Contact Info", "cistina-toolkit" ),
      "base" => "cristina_contact_info",
      "category" => __( "Cistina", "cistina-toolkit"),
      "params" => array(
         
         
         array(
            "type" => "attach_image",
            "heading" => esc_html__( "Contact Person Image", "cistina-toolkit" ),
            "param_name" => "img",
            "std" => "",
            "description" => esc_html__( "Upload Thumbnail Type Image", "cistina-toolkit" )
         ),
              
         array(
            "type" => "textarea",
            "heading" => esc_html__( "Contact Detail", "cistina-toolkit" ),
            "param_name" => "contact_detail",
            "std" => '123-456-7890',
            "description" => esc_html__( "Type Contact Detail", "cistina-toolkit" )
         ),
   
                
      ) 
   ) );

?>