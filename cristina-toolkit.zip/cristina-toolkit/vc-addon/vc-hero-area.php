<?php

   vc_map( 
   array(
      "name" => __( "Cistina Hero Area", "cistina-toolkit" ),
      "base" => "cristina_hero_area",
      "category" => __( "Cistina", "cistina-toolkit"),
      "params" => array(
         
         
         array(
            "type" => "textfield",
            "heading" => esc_html__( "Hero area height", "cistina-toolkit" ),
            "param_name" => "hero_area_height",
            "std" => 500,
            "description" => esc_html__( "Type Hero area height. Number Only: Example 500", "cistina-toolkit" )
         ),
         array(
            "type" => "textfield",
            "heading" => esc_html__( "Your Name", "cistina-toolkit" ),
            "param_name" => "hero_name",
            "std" => "Cristina Deo",
            "description" => esc_html__( "Type Your Name", "cistina-toolkit" )
         ), 
         array(
            "type" => "textfield",
            "heading" => esc_html__( "Your designation", "cistina-toolkit" ),
            "param_name" => "hero_designation",
            "std" => "UI/UX Developer - Designer - Content Creator",
            "description" => esc_html__( "Type Your designation", "cistina-toolkit" )
         ),
         array(
            "type" => "textfield",
            "heading" => esc_html__( "About Short Info", "cistina-toolkit" ),
            "param_name" => "hero_short_info",
            "std" => "Sure? You dont have a cousin who can do the job?",
            "description" => esc_html__( "Type About Short Info", "cistina-toolkit" )
         ), 
         array(
            "type" => "textfield",
            "heading" => esc_html__( "Hero button text", "cistina-toolkit" ),
            "param_name" => "hero_btn_text",
            "std" => "Download Resume",
            "description" => esc_html__( "Type Hero button text", "cistina-toolkit" )
         ),         


         
         array(
            "type" => "dropdown",
            "heading" => esc_html__( "Select Button link type", "cistina-toolkit" ),
            "param_name" => "hero_btn_button_link_type",
            "value" =>array(
              'Page To Link' => '1',
              'External Link' => '2',
              ),
            "std" => "1",
            "description" => esc_html__( "Select Button link type", "cistina-toolkit" )
         ),        
         
         
         
         array(
            "type" => "dropdown",
            "heading" => esc_html__( "Select page to link", "cistina-toolkit" ),
            "param_name" => "hero_btn_button_page_link",
            "value" =>  cristina_toolkit_get_page_list(),
            "dependency" => array(
                 "element" => 'hero_btn_button_link_type',
                 "value" => '1',
             ),           
            "description" => esc_html__( "Select page to link", "cistina-toolkit" )
         ),
         
         array(
            "type" => "textfield",
            "heading" => esc_html__( "External link", "cistina-toolkit" ),
            "param_name" => "hero_btn_button_external_link",
            "dependency" => array(
                 "element" => 'hero_btn_button_link_type',
                 "value" => '2',
             ),           
            "description" => esc_html__( "Type External link", "cistina-toolkit" )
         ),
         
                
         
        
       
      ) 
   ) );

?>