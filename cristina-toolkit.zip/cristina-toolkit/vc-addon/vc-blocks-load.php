<?php

if (!defined('ABSPATH')) die('-1');

// Class started
class CRISTINAVCExtendAddonClass {

    function __construct() {
        // We safely integrate with VC with this hook
        add_action( 'init', array( $this, 'CRISTINAIntegrateWithVC' ) );
    }
 
    public function CRISTINAIntegrateWithVC() {
        // Checks if Visual composer is not installed
        if ( ! defined( 'WPB_VC_VERSION' ) ) {
            add_action('admin_notices', array( $this, 'CRISTINAShowVcVersionNotice' ));
            return;
        }
 

        // visual composer addons.
         
         include (CRISTINA_ACC_PATH . '/vc-addon/vc-hero-area.php');
         include (CRISTINA_ACC_PATH . '/vc-addon/vc-common-tilte.php');
         include (CRISTINA_ACC_PATH . '/vc-addon/vc-common-btn.php');
         include (CRISTINA_ACC_PATH . '/vc-addon/vc-skilled.php');
         include (CRISTINA_ACC_PATH . '/vc-addon/vc_experience.php');
         include (CRISTINA_ACC_PATH . '/vc-addon/vc_education.php');
         include (CRISTINA_ACC_PATH . '/vc-addon/vc-contact-info.php');
         include (CRISTINA_ACC_PATH . '/vc-addon/vc-project.php');
         

    }

    // show visual composer version
    public function CRISTINAShowVcVersionNotice() {
        $theme_data = wp_get_theme();
        echo '
        <div class="notice notice-warning">
          <p>'.sprintf(__('<strong>%s</strong> recommends <strong><a href="'.site_url().'/wp-admin/themes.php?page=tgmpa-install-plugins" target="_blank">Visual Composer</a></strong> plugin to be installed and activated on your site.', 'educad-themesold'), $theme_data->get('Name')).'</p>
        </div>';
    }
}
// Finally initialize code
new CRISTINAVCExtendAddonClass();