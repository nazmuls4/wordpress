<?php

   vc_map( 
   array(
      "name" => __( "Cistina Project", "cistina-toolkit" ),
      "base" => "cristina_project_shotcode",
      "category" => __( "Cistina", "cistina-toolkit"),
      "params" => array(
         
       
      ) 
   ) );

?>