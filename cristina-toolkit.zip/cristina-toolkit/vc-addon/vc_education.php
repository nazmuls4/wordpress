<?php

   vc_map( 
   array(
      "name" => __( "Cistina Education", "cistina-toolkit" ),
      "base" => "cristina_education",
      "category" => __( "Cistina", "cistina-toolkit"),
      "params" => array(
         
         
         array(
            "type" => "textfield",
            "heading" => esc_html__( "Education Start Year", "cistina-toolkit" ),
            "param_name" => "start_date",
            "std" => '2010',
            "description" => esc_html__( "Select Education Start Date", "cistina-toolkit" )
         ),
         array(
            "type" => "textfield",
            "heading" => esc_html__( "Education End Year", "cistina-toolkit" ),
            "param_name" => "end_date",
            "std" => '2014',
            "description" => esc_html__( "Select Education End Year", "cistina-toolkit" )
         ),
         array(
            "type" => "textfield",
            "heading" => esc_html__( "University name", "cistina-toolkit" ),
            "param_name" => "university_name",
            "std" => 'University of Design',
            "description" => esc_html__( "Type University name", "cistina-toolkit" )
         ),
           
         array(
            "type" => "textfield",
            "heading" => esc_html__( "Degree title", "cistina-toolkit" ),
            "param_name" => "degree_name",
            "std" => 'Graphics Design',
            "description" => esc_html__( "Type Experience title", "cistina-toolkit" )
         ),
         array(
            "type" => "textarea",
            "heading" => esc_html__( "Degree info", "cistina-toolkit" ),
            "param_name" => "about_degree_info",
            "std" => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Molestiae, ipsa, ipsum. Explicabo doloribus ea nisi consectetur, fuga quo quam nobis! Deleniti',
            "description" => esc_html__( "Type Experience info", "cistina-toolkit" )
         )
              
           
                
      ) 
   ) );

?>