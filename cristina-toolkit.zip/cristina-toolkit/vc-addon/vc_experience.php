<?php

   vc_map( 
   array(
      "name" => __( "Cistina Experience", "cistina-toolkit" ),
      "base" => "cristina_experience",
      "category" => __( "Cistina", "cistina-toolkit"),
      "params" => array(
         
         
         array(
            "type" => "textfield",
            "heading" => esc_html__( "Job Start Year", "cistina-toolkit" ),
            "param_name" => "start_date",
            "std" => '2010',
            "description" => esc_html__( "Select Job Start Date", "cistina-toolkit" )
         ),
         array(
            "type" => "textfield",
            "heading" => esc_html__( "Job End Year", "cistina-toolkit" ),
            "param_name" => "end_date",
            "std" => '2014',
            "description" => esc_html__( "Select Job End Year", "cistina-toolkit" )
         ),
         array(
            "type" => "textfield",
            "heading" => esc_html__( "Company name", "cistina-toolkit" ),
            "param_name" => "company_name",
            "std" => 'Creative Agency',
            "description" => esc_html__( "Type Company name", "cistina-toolkit" )
         ),
           
         array(
            "type" => "textfield",
            "heading" => esc_html__( "Experience title", "cistina-toolkit" ),
            "param_name" => "experience_title",
            "std" => 'Graphics Design',
            "description" => esc_html__( "Type Experience title", "cistina-toolkit" )
         ),
         array(
            "type" => "textarea",
            "heading" => esc_html__( "Experience info", "cistina-toolkit" ),
            "param_name" => "experience_info",
            "std" => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Molestiae, ipsa, ipsum. Explicabo doloribus ea nisi consectetur, fuga quo quam nobis! Deleniti',
            "description" => esc_html__( "Type Experience info", "cistina-toolkit" )
         )
              
           
                
      ) 
   ) );

?>