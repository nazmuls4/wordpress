<?php

   vc_map( 
   array(
      "name" => __( "Cistina Button", "cistina-toolkit" ),
      "base" => "cristina_button",
      "category" => __( "Cistina", "cistina-toolkit"),
      "params" => array(
         
         array(
            "type" => "textfield",
            "heading" => esc_html__( "Button text", "cistina-toolkit" ),
            "param_name" => "btn_text",
            "std" => "Download Resume",
            "description" => esc_html__( "Type button text", "cistina-toolkit" )
         ),        

         
         array(
            "type" => "dropdown",
            "heading" => esc_html__( "Select Button link type", "cistina-toolkit" ),
            "param_name" => "button_link_type",
            "value" =>array(
              'Page To Link' => '1',
              'External Link' => '2',
              ),
            "std" => "1",
            "description" => esc_html__( "Select Button link type", "cistina-toolkit" )
         ),        
         
         
         
         array(
            "type" => "dropdown",
            "heading" => esc_html__( "Select Button page to link", "cistina-toolkit" ),
            "param_name" => "button_page_link",
            "value" =>  cristina_toolkit_get_page_list(),
            "dependency" => array(
                 "element" => 'button_link_type',
                 "value" => '1',
             ),           
            "description" => esc_html__( "Select Button page to link", "cistina-toolkit" )
         ),
         
         array(
            "type" => "textfield",
            "heading" => esc_html__( "External link", "cistina-toolkit" ),
            "param_name" => "button_external_link",
            "dependency" => array(
                 "element" => 'button_link_type',
                 "value" => '2',
             ),           
            "description" => esc_html__( "Type External link", "cistina-toolkit" )
         ),


         array(
            "type" => "dropdown",
            "heading" => esc_html__( "Select Button type", "cistina-toolkit" ),
            "param_name" => "button_type",
            "value" =>array(
              'Filled Button' => 'btn btn-sm btn-custom btn-round',
              'Bordared Button' => 'btn btn-sm btn-custom btn-round bordered',
              ),
            "std" => "1",
            "description" => esc_html__( "Select Button type", "cistina-toolkit" )
         ),    
             
       
      ) 
   ) );

?>