<?php

function cristina_button_shortcode($atts){
    extract( shortcode_atts( array(

        'btn_text' => 'Download Resume',
        'button_link_type' => 1,
        'button_page_link' => '',
        'button_external_link' => '',
        'button_type' => 'btn btn-sm btn-custom btn-round',
    ), $atts) );     

    if ($button_link_type == 1) {
        $btn_page_link_array = get_page_link( $button_page_link );
    }else{
        $btn_page_link_array = $button_external_link;
    }

    $cristina_button = '
       <div class="cristina-common-btn-area">
            <div class="text-center cristina-btn">
                <a href="'.$btn_page_link_array.'" class="'.$button_type.'"><i class="fa fa-download"></i> '.$btn_text.'</a>
            </div>
        </div> 
    ';
    return $cristina_button;
}
add_shortcode('cristina_button', 'cristina_button_shortcode');  