<?php

function cristina_skilled_shortcode($atts){
    extract( shortcode_atts( array(
        'progress_title' => 'Photoshop',
        'progress_value' => '25',
    ), $atts) );     

   

    $cristina_skilled = '
        <div class="cristina-progress-content">
            <div class="progress-title"><span>'.$progress_title.'</span></div>
            <div class="progress cristina-progress-bar">          
                <div class="progress-bar" role="progressbar" style="width: '.$progress_value.'%" aria-valuenow="'.$progress_value.'" aria-valuemin="0" aria-valuemax="100">
                    <div class="progress-bar-progress-value">
                        '.$progress_value.'%
                    </div>

                </div>
            </div>
        </div>
    ';
    return $cristina_skilled;
}
add_shortcode('cristina_skilled', 'cristina_skilled_shortcode');  