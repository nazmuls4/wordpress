<?php

function cristina_project_shotcode_shortcode($atts){
    extract( shortcode_atts( array(
        'count' => -1,
    ), $atts) );     

    $q = new WP_Query( array('posts_per_page' => $count,'post_type' => 'project')); 

   
        $dynamic_number = rand(000545645,55646465645);
    
        

        $cristina_project_shotcode = '<div class="">
            <script>
                jQuery(document).ready(function($){
                    
                    $(".project_shorting_list li").click(function(){
                        $(".project_shorting_list li").removeClass("active");
                        $(this).addClass("active");

                        var selector = $(this).attr("data-filter");
                        $(".project-list-item-'.$dynamic_number.'").isotope({
                            filter: selector
                        });
                        return false;
                    });


                });
                jQuery(window).load(function(){
                       $(".project-list-item-'.$dynamic_number.'").isotope(); 

                });
            </script>


        ';

        $cristina_project_shotcode .= '
         <div class="row">
            <div class="col-lg-12">
                <div class="portfolioFilter">
                    <ul class="project_shorting_list">
                        <li class="active" data-filter="*">All</li>';

                        $project_categories = get_terms( 'project_category');
                        if ( ! empty( $project_categories ) && ! is_wp_error( $project_categories ) ){
                            foreach ( $project_categories as $categories ) {
                                $cristina_project_shotcode .= '<li data-filter=".' . $categories->slug . '">' . $categories->name . '</li>'; 
                            }
                            
                           
                        }
                        $cristina_project_shotcode .= '                       

                       

                    </ul>
                </div>
            </div>
        </div>

        ';


        $cristina_project_shotcode .= ' <div class="row project-list-item-'.$dynamic_number.'"> ';
        while($q->have_posts()) : $q->the_post();

        $terms = get_the_terms( get_the_ID(), 'project_category' );
        if ($terms && ! is_wp_error( $terms )) {
            $cat_list = array();
            foreach ( $terms as $term ) {
                $cat_list[] = $term->slug;
            }                                 
            $assign_cat_list = join( "  ", $cat_list );

        }else{
            $assign_cat_list = '';

        }

        $idd = get_the_ID();        
        $post_content = get_the_content();
        $cristina_project_shotcode .= '

            <div class="col-lg-4 col-sm-6 '.$assign_cat_list.'">
                <div class="cirstina-single-project" style="background: url('.get_the_post_thumbnail_url( $idd, 'large').');">
                    <div class="cristina-single-project-overlay">
                        <div class="cristina-single-project-overlay-cell text-center">
                             <a href="'.get_the_permalink( $idd).'"><i class="fa fa-search"></i></a>
                             <a href="'.get_the_permalink( $idd).'"><h3 class="text-uppercase mt-4 f-16">View More</h3></a>
                        </div>
                       
                    </div>
                </div>
            </div>';
            endwhile;
        $cristina_project_shotcode .= ' </div>';       
        $cristina_project_shotcode .= ' </div>';       
        wp_reset_query();

        $cristina_project_shotcode .= ' 


    ';
    return $cristina_project_shotcode;
}
add_shortcode('cristina_project_shotcode', 'cristina_project_shotcode_shortcode');  