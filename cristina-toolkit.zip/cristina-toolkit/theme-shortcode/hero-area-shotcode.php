<?php

function cristina_hero_area_shortcode($atts){
    extract( shortcode_atts( array(
        'hero_area_height' => 500,
        'hero_name' => 'Cristina Deo',
        'hero_designation' => 'UI/UX Developer - Designer - Content Creator',
        'hero_short_info' => 'Sure? You dont have a cousin who can do the job?',
        'hero_btn_text' => 'Download Resume',
        'hero_btn_button_link_type' => 1,
        'hero_btn_button_page_link' => '',
        'hero_btn_button_external_link' => '',
    ), $atts) );     

    if ($hero_btn_button_link_type == 1) {
        $hero_btn_page_link_array = get_page_link( $hero_btn_button_page_link );
    }else{
        $hero_btn_page_link_array = $hero_btn_button_external_link;
    }

    $cristina_hero_area = '
       <div class="cristinia-hero-area-table" style="height:'.$hero_area_height.'px; ">
            <div class="cristinia-hero-area-table-cell text-center">
                <h3>Hello ! I am <span>'.$hero_name.'</span></h3>
                <div class="cristinia-about-title">
                    <p class="cristinia-designation text-reveal"><span>'.$hero_designation.'</span></p>
                    <p class="cristinia-before-cta text-reveal"><span>'.$hero_short_info.'</span></p>
                </div>
                <div class="text-center mt-5 cristina-btn">
                    <a href="'.$hero_btn_page_link_array.'" class="btn btn-sm btn-custom btn-round"><i class="fa fa-forward"></i> '.$hero_btn_text.'</a>
                </div>
            </div>
        </div> 
    ';
    return $cristina_hero_area;
}
add_shortcode('cristina_hero_area', 'cristina_hero_area_shortcode');  