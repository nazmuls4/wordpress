<?php

function cristina_education_shortcode($atts){
    extract( shortcode_atts( array(
        'start_date' => '2010',
        'end_date' => '2014',
        'university_name' => 'University of Design',
        'degree_name' => 'Graphics Design',
        'about_degree_info' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Molestiae, ipsa, ipsum. Explicabo doloribus ea nisi consectetur, fuga quo quam nobis! Deleniti',
    ), $atts) );     

   

    $cristina_education = '
        <div class="cristina-Experience">
            <div class="cristinacv-heading">
                <h3>
                    <span>'.$start_date.'</span> - <span>'.$end_date.'</span>
                </h3>
                <h3 class="mt-4">'.$university_name.'</h3>
            </div>
            <div class="cristinacv-cv-content">
                <h4 class="mb-20 mt-0">'.$degree_name.'</h4>
                '.wpautop( $about_degree_info ).'
            </div>
        </div>
    ';
    return $cristina_education;
}
add_shortcode('cristina_education', 'cristina_education_shortcode');  