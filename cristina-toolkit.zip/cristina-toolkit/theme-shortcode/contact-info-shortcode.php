<?php

function cristina_contact_info_shortcode($atts){
    extract( shortcode_atts( array(
        'img' => '',
        'contact_detail' => '123-456-7890',
    ), $atts) );     

    $img_array = wp_get_attachment_image_src( $img, 'thumbnail');

    $cristina_contact_info = '
       <div class="cristina-contact-info-table">
         <div class="cristina-contact-info-table-cell text-center">
           <div class="contact-img">
            <img src="'.$img_array[0].'" class="img-fluid rounded-circle" alt="">
           </div>
           <div class="cotact-detail">
              '.wpautop( $contact_detail).'
              <a href="mailto:"></a>
           </div>
         </div>
       </div>
    ';
    return $cristina_contact_info;
}
add_shortcode('cristina_contact_info', 'cristina_contact_info_shortcode');  