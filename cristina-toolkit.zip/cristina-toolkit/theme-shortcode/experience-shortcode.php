<?php

function cristina_experience_shortcode($atts){
    extract( shortcode_atts( array(
        'start_date' => '2010',
        'end_date' => '2014',
        'company_name' => 'Creative Agency',
        'experience_title' => 'Graphics Design',
        'experience_info' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Molestiae, ipsa, ipsum. Explicabo doloribus ea nisi consectetur, fuga quo quam nobis! Deleniti',
    ), $atts) );     

   

    $cristina_experience = '
        <div class="cristina-Experience">
            <div class="cristinacv-heading">
                <h3>
                    <span>'.$start_date.'</span> - <span>'.$end_date.'</span>
                </h3>
                <h3 class="mt-4">'.$company_name.'</h3>
            </div>
            <div class="cristinacv-cv-content">
                <h4 class="mb-20 mt-0">'.$experience_title.'</h4>
                '.wpautop( $experience_info ).'
            </div>
        </div>
    ';
    return $cristina_experience;
}
add_shortcode('cristina_experience', 'cristina_experience_shortcode');  