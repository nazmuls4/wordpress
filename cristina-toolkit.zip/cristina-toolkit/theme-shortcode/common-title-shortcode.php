<?php

function cristina_common_title_shortcode($atts){
    extract( shortcode_atts( array(
        'small_heading' => 'Who am i ?',
        'big_heading' => 'Personal Details',
        'heading_text_position' => 'text-left',
    ), $atts) );     


    $cristina_common_title = '
       <div class="cristina-common-title '.$heading_text_position.'">';
       if (!empty($small_heading)) {
           $cristina_common_title .= '
                <p class="cristina-sub-title text-muted mb-0">'.$small_heading.'</p>
           ';
       }       

        if (!empty($big_heading)) {
            $cristina_common_title .= ' 
                <h2 class="cristina-title m-0 text-uppercase">'.$big_heading.'</h2>
            ';
        }
       $cristina_common_title .= '        

            
            <hr>
        </div> 
    ';
    return $cristina_common_title;
}
add_shortcode('cristina_common_title', 'cristina_common_title_shortcode');  